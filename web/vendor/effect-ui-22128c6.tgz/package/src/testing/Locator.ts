/**
 * Locators over a minimal structural tree, so one locator works on a story's
 * view value and on `TestHost`'s rendered tree alike.
 *
 * A node is anything with some of `tag`, `attrs`, `text` and `children`:
 * an element has a `tag`, a text node has `text`. Locators match elements.
 * `text` matches the innermost elements whose text contains the string,
 * `attr` and `testId` match by attribute, and `inside` narrows a locator to
 * the subtree of another.
 *
 * **Example** (Finding a row's button)
 *
 * ```ts import.meta.vitest
 * import { Locator } from "@effect/ui/testing"
 *
 * const row = (id: string) => ({
 *   tag: "li",
 *   attrs: { "data-testid": id },
 *   children: [{ tag: "button", children: [{ text: "Save" }] }]
 * })
 * const tree = { tag: "ul", children: [row("row-1"), row("row-2")] }
 *
 * const button = Locator.get(tree, Locator.inside(Locator.testId("row-2"), Locator.text("Save")))
 * console.log(button === tree.children[1].children[0]) // true
 * ```
 *
 * @stability experimental
 * @since 0.1.0
 */

/**
 * The structural tree every locator runs over.
 *
 * **Details**
 *
 * `props` holds the typed values set with `.prop`, such as a field's
 * `value` and `checked`, which aren't attributes. A scene's view value and a
 * `TestHost` tree both have them, and a vocabulary's readers, such as
 * `HtmlLocator.value`, read them.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Node {
  readonly tag?: string | undefined
  readonly attrs?: Readonly<Record<string, string | undefined>> | undefined
  readonly props?: Readonly<Record<string, unknown>> | undefined
  readonly text?: string | undefined
  readonly children?: ReadonlyArray<Node> | undefined
}

/**
 * Finds elements under a root, in document order.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Locator {
  readonly description: string
  readonly all: <N extends Node>(root: N) => ReadonlyArray<N>
}

/**
 * The text of a node and everything under it.
 *
 * @stability experimental
 * @category getters
 * @since 0.1.0
 */
export const textOf = (node: Node): string => {
  let text = ""
  preorder(node, (node) => {
    if (node.text === undefined || node.tag !== undefined) return true
    text += node.text
    return false
  })
  return text
}

/**
 * Every element under `root`, `root` included, in document order.
 *
 * @stability experimental
 * @category getters
 * @since 0.1.0
 */
export const elements = <N extends Node>(root: N): ReadonlyArray<N> => {
  const out: Array<N> = []
  preorder(root, (node) => {
    if (node.tag !== undefined) out.push(node as N)
    return true
  })
  return out
}

/**
 * Visits nodes in document order without recursion. Returning false from
 * `visit` skips that node's children.
 */
const preorder = (root: Node, visit: (node: Node) => boolean): void => {
  const pending: Array<Node> = [root]
  while (pending.length > 0) {
    const node = pending.pop()!
    if (!visit(node)) continue
    const children = node.children
    if (children === undefined) continue
    for (let index = children.length - 1; index >= 0; index--) {
      const child = children[index]
      if (child !== undefined) pending.push(child)
    }
  }
}

/**
 * The elements directly under `node`. A node with children but no tag, such
 * as the content a story shows under a child's slots, is seen through.
 */
const childElements = (node: Node): ReadonlyArray<Node> => {
  const out: Array<Node> = []
  preorder(node, (child) => {
    if (child === node || child.tag === undefined) return true
    out.push(child)
    return false
  })
  return out
}

const make = (
  description: string,
  all: <N extends Node>(root: N) => ReadonlyArray<N>
): Locator => ({
  description,
  all
})

/**
 * The innermost elements whose text contains `text`, or equals it with
 * `{ exact: true }`.
 *
 * @stability experimental
 * @category locators
 * @since 0.1.0
 */
export const text = (
  text: string,
  options?: { readonly exact?: boolean | undefined }
): Locator => {
  const matches = (node: Node) =>
    options?.exact === true
      ? textOf(node).trim() === text
      : textOf(node).includes(text)
  return make(
    `text ${JSON.stringify(text)}`,
    (root) =>
      elements(root).filter((node) =>
        matches(node) && !childElements(node).some(matches)
      )
  )
}

/**
 * Elements with the attribute `name`, equal to `value` when one is given.
 *
 * @stability experimental
 * @category locators
 * @since 0.1.0
 */
export const attr = (name: string, value?: string): Locator =>
  make(
    value === undefined ? `[${name}]` : `[${name}=${JSON.stringify(value)}]`,
    (root) =>
      elements(root).filter((node) =>
        value === undefined
          ? node.attrs?.[name] !== undefined
          : node.attrs?.[name] === value
      )
  )

/**
 * Elements with `data-testid` equal to `id`.
 *
 * @stability experimental
 * @category locators
 * @since 0.1.0
 */
export const testId = (id: string): Locator => attr("data-testid", id)

/**
 * Elements with the tag `tag`.
 *
 * @stability experimental
 * @category locators
 * @since 0.1.0
 */
export const tag = (tag: string): Locator =>
  make(`<${tag}>`, (root) => elements(root).filter((node) => node.tag === tag))

/**
 * What `locator` finds inside the elements `container` finds.
 *
 * @stability experimental
 * @category locators
 * @since 0.1.0
 */
export const inside = (container: Locator, locator: Locator): Locator =>
  make(`${locator.description} inside ${container.description}`, (root) => {
    const found = new Set<any>()
    for (const outer of container.all(root)) {
      for (const node of locator.all(outer)) {
        if (node !== outer) found.add(node)
      }
    }
    return elements(root).filter((node) => found.has(node))
  })

/**
 * Every match, in document order.
 *
 * @stability experimental
 * @category queries
 * @since 0.1.0
 */
export const all = <N extends Node>(
  root: N,
  locator: Locator
): ReadonlyArray<N> => locator.all(root)

/**
 * The one match, or `undefined`. Throws when there are several.
 *
 * @stability experimental
 * @category queries
 * @since 0.1.0
 */
export const query = <N extends Node>(
  root: N,
  locator: Locator
): N | undefined => {
  const found = locator.all(root)
  if (found.length > 1) {
    throw new Error(
      `Locator: ${found.length} elements match ${locator.description}`
    )
  }
  return found[0]
}

/**
 * The one match. Throws when there's none or several.
 *
 * @stability experimental
 * @category queries
 * @since 0.1.0
 */
export const get = <N extends Node>(root: N, locator: Locator): N => {
  const found = query(root, locator)
  if (found === undefined) {
    throw new Error(`Locator: nothing matches ${locator.description}`)
  }
  return found
}

/**
 * A node that can receive events, as `TestHost`'s nodes can.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Firable extends Node {
  readonly fire: (event: string, payload: unknown) => void
}

/**
 * Sends `event` with `payload` to `node`. The innermost element with a
 * handler for it, `node` or an ancestor, gets it.
 *
 * **Details**
 *
 * Payloads are plain data shaped by the vocabulary, such as `{ value }` for
 * `input`. A scene's view value has no host, so scene tests use the
 * `fire` and `click` steps of `Scene.Steps` instead.
 *
 * @stability experimental
 * @category events
 * @since 0.1.0
 */
export const fire = (
  node: Firable,
  event: string,
  payload: unknown = {}
): void => node.fire(event, payload)
