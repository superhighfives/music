/**
 * Pure keyboard helpers over `Html.KeyPayload`: turn a table of single-key
 * shortcuts into a handler for `HtmlSubscription.onDocument` or an
 * element's `keydown` handler.
 *
 * @stability experimental
 * @since 0.1.0
 */
import type * as Html from "./Html.ts"
import type * as HtmlSubscription from "./HtmlSubscription.ts"
import * as keys from "./internal/keys.ts"

/**
 * One row of a table for {@link shortcuts}: a key to match, the message to
 * produce, and optional modifier and guard overrides.
 *
 * **Details**
 *
 * `ctrl`, `alt` and `meta` default to `false`. `mod: true` matches a
 * cross-platform primary shortcut — either `ctrl` or `meta` pressed, but not
 * both — and takes precedence over `ctrl` and `meta`. `shift` is ignored
 * unless set, so a character key such as `"?"` or `"G"` matches regardless of
 * whether the user's keyboard layout requires Shift to type it. `whileTyping`
 * defaults to `false` (ignored when `editable` is true), `whileModal`
 * defaults to `false` (ignored on a document listener while a modal is open),
 * and `repeat` defaults to `false` (ignored while the key auto-repeats).
 *
 * Set `whileModal: true` on document shortcut rows that should match inside
 * a modal, such as a dialog's own `mod+s` shortcut.
 *
 * @stability experimental
 * @category events
 * @since 0.1.0
 */
export interface Shortcut<Msg> {
  readonly key: string
  readonly message: Msg
  readonly mod?: boolean | undefined
  readonly shift?: boolean | undefined
  readonly ctrl?: boolean | undefined
  readonly alt?: boolean | undefined
  readonly meta?: boolean | undefined
  readonly whileTyping?: boolean | undefined
  readonly whileModal?: boolean | undefined
  readonly repeat?: boolean | undefined
}

/**
 * A row of `HtmlSubscription.keySequences` that takes several presses:
 * `keys` in order, such as `["g", "l"]`, in place of a {@link Shortcut}'s
 * `key`.
 *
 * **Details**
 *
 * The modifiers and guards apply to every press of the row, as they do to a
 * {@link Shortcut}'s one press.
 *
 * @stability experimental
 * @category events
 * @since 0.1.0
 */
export interface Sequence<Msg> extends Omit<Shortcut<Msg>, "key"> {
  readonly keys: readonly [string, ...ReadonlyArray<string>]
  readonly key?: never
}

/**
 * Turns a table of single-key {@link Shortcut} rows into a pure `keydown` or
 * `keyup` handler usable with `HtmlSubscription.onDocument` or an element's
 * `keydown` handler.
 *
 * **Details**
 *
 * Events with `composing` are always ignored, and on document listeners
 * (`HtmlSubscription.onDocument`) events with `defaultPrevented` are ignored as
 * well. While `modal` is true, only rows with `whileModal: true` can match.
 * Element payloads carry neither flag. Each row is checked in order and the
 * first match returns its `message`. Unmatched events return
 * `undefined`, so `{ preventDefault: true }` cancels the browser's default
 * only for matched shortcuts. On element handlers, returning `undefined` does
 * not fall through to an ancestor element's handler because the host stops at
 * the innermost element that listens; a document listener can still receive it.
 *
 * Because this returns a plain handler function with no state and no
 * listener registration, it can be combined with other keydown logic inside
 * an instance's single document listener. For a table that is the whole
 * document listener, use `HtmlSubscription.shortcuts`.
 *
 * **Example** (Shortcuts on an element)
 *
 * ```ts import.meta.vitest
 * import { UiSchema } from "@effect/ui"
 * import { Html, HtmlKeyboard } from "@effect/ui/html"
 * import { HtmlScene } from "@effect/ui/html/testing"
 * import { Locator } from "@effect/ui/testing"
 * import { Effect, Schema } from "effect"
 *
 * const Message = UiSchema.TaggedEnum({ PressedNext: {}, PressedPrevious: {} })
 *
 * const Rows = Html.component({
 *   name: "Rows",
 *   model: Schema.Number,
 *   message: Message
 * }).make({
 *   init: () => 0,
 *   update: { PressedNext: ($) => $.model + 1, PressedPrevious: ($) => $.model - 1 },
 *   view: (h, row) =>
 *     h.button.on("keydown",
 *       HtmlKeyboard.shortcuts([
 *         { key: "j", message: Message.PressedNext() },
 *         { key: "k", message: Message.PressedPrevious() }
 *       ]),
 *       { preventDefault: true }
 *     ).children(`row ${row}`)
 * })
 *
 * Effect.gen(function*() {
 *   const s = yield* HtmlScene.make(Rows, {})
 *   s.keydown(Locator.tag("button"), "x").expectIgnored()
 *     .keydown(Locator.tag("button"), "j").expectDefaultPrevented()
 *     .expect(Locator.text("row 1")).toExist()
 * }).pipe(Effect.scoped, Effect.runSync)
 * ```
 *
 * @stability experimental
 * @category events
 * @since 0.1.0
 */
export const shortcuts = <const Rows extends ReadonlyArray<Shortcut<unknown>>>(
  table: Rows
): (
  payload: Html.KeyPayload | HtmlSubscription.GlobalPayload<Html.KeyPayload>
) => Rows[number]["message"] | undefined =>
(payload) => {
  if (
    ("defaultPrevented" in payload && payload.defaultPrevented) ||
    payload.composing
  ) return undefined
  for (const shortcut of table) {
    if (keys.matches(shortcut, shortcut.key, payload)) {
      return shortcut.message as Rows[number]["message"]
    }
  }
  return undefined
}
